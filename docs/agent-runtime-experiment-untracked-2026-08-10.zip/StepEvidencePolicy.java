package com.paicli.agent;

import java.util.List;
import java.util.Locale;

/** 按计划步骤类型检查 Worker 是否真的执行了最低限度的动作。 */
final class StepEvidencePolicy {
    private StepEvidencePolicy() {
    }

    static Assessment assess(String stepType, StepEvidence evidence) {
        StepEvidence actual = evidence == null ? StepEvidence.empty() : evidence;
        String normalized = stepType == null ? "" : stepType.trim().toUpperCase(Locale.ROOT);
        return switch (normalized) {
            case "FILE_READ" -> requireSuccessfulTool(actual, List.of("read_file"),
                    "步骤要求读取文件，但没有成功的 read_file 证据");
            case "FILE_WRITE" -> requireSuccessfulTool(actual, List.of("write_file", "create_project"),
                    "步骤要求修改文件，但没有成功的 write_file/create_project 证据");
            case "COMMAND", "VERIFICATION" -> requireSuccessfulCommand(actual);
            default -> Assessment.pass();
        };
    }

    private static Assessment requireSuccessfulTool(StepEvidence evidence, List<String> toolNames,
                                                     String failureMessage) {
        boolean passed = evidence.toolCalls().stream()
                .anyMatch(call -> toolNames.contains(call.toolName()) && call.successful());
        return passed ? Assessment.pass() : Assessment.fail(failureMessage);
    }

    private static Assessment requireSuccessfulCommand(StepEvidence evidence) {
        boolean passed = evidence.callsFor("execute_command").stream()
                .anyMatch(StepEvidence.ToolCallEvidence::commandSucceeded);
        return passed
                ? Assessment.pass()
                : Assessment.fail("步骤要求执行命令或验证，但没有 exit code 为 0 的 execute_command 证据");
    }

    record Assessment(boolean satisfied, String detail) {
        static Assessment pass() {
            return new Assessment(true, "");
        }

        static Assessment fail(String detail) {
            return new Assessment(false, detail);
        }
    }
}
