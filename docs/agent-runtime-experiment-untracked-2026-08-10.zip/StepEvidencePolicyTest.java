package com.paicli.agent;

import com.paicli.tool.ToolRegistry.ToolExecutionResult;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class StepEvidencePolicyTest {

    @Test
    void fileReadRequiresSuccessfulReadFileEvidence() {
        assertFalse(StepEvidencePolicy.assess("FILE_READ", evidence(
                tool("glob_files", "files: SafeDivider.java"))).satisfied());
        assertFalse(StepEvidencePolicy.assess("FILE_READ", evidence(
                tool("read_file", "读取文件失败: not found"))).satisfied());
        assertTrue(StepEvidencePolicy.assess("FILE_READ", evidence(
                tool("read_file", "1 | package eval;"))).satisfied());
    }

    @Test
    void fileWriteRequiresSuccessfulWriteEvidence() {
        assertFalse(StepEvidencePolicy.assess("FILE_WRITE", StepEvidence.empty()).satisfied());
        assertFalse(StepEvidencePolicy.assess("FILE_WRITE", evidence(
                tool("write_file", "写入文件失败: denied"))).satisfied());
        assertTrue(StepEvidencePolicy.assess("FILE_WRITE", evidence(
                tool("write_file", "文件已写入: src/App.java"))).satisfied());
    }

    @Test
    void verificationRequiresZeroExitCommand() {
        assertFalse(StepEvidencePolicy.assess("VERIFICATION", evidence(
                tool("execute_command", "命令执行完成 (exit code: 1)\nfailed"))).satisfied());
        assertTrue(StepEvidencePolicy.assess("COMMAND", evidence(
                tool("execute_command", "命令执行完成 (exit code: 0)\nBUILD SUCCESS"))).satisfied());
    }

    @Test
    void analysisAllowsTextOnlyExecution() {
        assertTrue(StepEvidencePolicy.assess("ANALYSIS", StepEvidence.empty()).satisfied());
        assertTrue(StepEvidencePolicy.assess("", StepEvidence.empty()).satisfied());
    }

    @Test
    void reviewerContextContainsToolFactsAndCapsPayload() {
        StepEvidence evidence = evidence(new ToolExecutionResult(
                "call-1", "read_file", "{\"path\":\"src/App.java\"}",
                "x".repeat(7_000), 12, false, List.of()));

        String context = evidence.toReviewerContext();

        assertTrue(context.contains("read_file"));
        assertTrue(context.contains("src/App.java"));
        assertTrue(context.contains("已截断"));
    }

    private static StepEvidence evidence(ToolExecutionResult... results) {
        return StepEvidence.from(List.of(results));
    }

    private static ToolExecutionResult tool(String name, String result) {
        return new ToolExecutionResult("call-1", name, "{}", result, 1, false, List.of());
    }
}
