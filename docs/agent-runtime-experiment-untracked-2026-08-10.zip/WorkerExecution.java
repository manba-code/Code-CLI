package com.paicli.agent;

/** Worker 的自然语言结果及同一次执行产生的工具证据。 */
record WorkerExecution(AgentMessage message, StepEvidence evidence) {
    WorkerExecution {
        evidence = evidence == null ? StepEvidence.empty() : evidence;
    }
}
