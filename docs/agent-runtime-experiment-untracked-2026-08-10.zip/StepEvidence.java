package com.paicli.agent;

import com.paicli.tool.ToolRegistry.ToolExecutionResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Worker 执行一个步骤时产生的可审计工具证据。
 *
 * 证据按单次 Worker execute 调用局部收集，不挂在共享 ToolRegistry 上，
 * 避免并行步骤之间相互污染。
 */
record StepEvidence(List<ToolCallEvidence> toolCalls) {
    private static final int MAX_ARGUMENT_CHARS = 2_000;
    private static final int MAX_RESULT_CHARS = 6_000;
    private static final int MAX_REVIEW_CONTEXT_CHARS = 16_000;

    StepEvidence {
        toolCalls = toolCalls == null ? List.of() : List.copyOf(toolCalls);
    }

    static StepEvidence empty() {
        return new StepEvidence(List.of());
    }

    static StepEvidence from(List<ToolExecutionResult> results) {
        if (results == null || results.isEmpty()) {
            return empty();
        }
        List<ToolCallEvidence> evidence = new ArrayList<>(results.size());
        for (ToolExecutionResult result : results) {
            evidence.add(new ToolCallEvidence(
                    result.name(),
                    abbreviate(result.argumentsJson(), MAX_ARGUMENT_CHARS),
                    abbreviate(result.result(), MAX_RESULT_CHARS),
                    result.elapsedMillis(),
                    result.timedOut()
            ));
        }
        return new StepEvidence(evidence);
    }

    StepEvidence append(List<ToolExecutionResult> results) {
        StepEvidence additional = from(results);
        if (additional.toolCalls().isEmpty()) {
            return this;
        }
        List<ToolCallEvidence> merged = new ArrayList<>(toolCalls);
        merged.addAll(additional.toolCalls());
        return new StepEvidence(merged);
    }

    boolean usedTool(String name) {
        return toolCalls.stream().anyMatch(call -> call.toolName().equals(name));
    }

    List<ToolCallEvidence> callsFor(String name) {
        return toolCalls.stream().filter(call -> call.toolName().equals(name)).toList();
    }

    String toReviewerContext() {
        if (toolCalls.isEmpty()) {
            return "（没有工具执行证据）";
        }
        StringBuilder context = new StringBuilder();
        for (int i = 0; i < toolCalls.size(); i++) {
            ToolCallEvidence call = toolCalls.get(i);
            context.append("证据 #").append(i + 1).append('\n')
                    .append("- tool: ").append(call.toolName()).append('\n')
                    .append("- arguments: ").append(call.arguments()).append('\n')
                    .append("- elapsed_ms: ").append(call.elapsedMillis()).append('\n')
                    .append("- timed_out: ").append(call.timedOut()).append('\n')
                    .append("- result:\n").append(indent(call.result())).append('\n');
            if (context.length() >= MAX_REVIEW_CONTEXT_CHARS) {
                return context.substring(0, MAX_REVIEW_CONTEXT_CHARS)
                        + "\n...（执行证据已按上下文预算截断）";
            }
        }
        return context.toString().trim();
    }

    private static String indent(String value) {
        String normalized = value == null || value.isBlank() ? "（空结果）" : value.trim();
        return "  " + normalized.replace("\n", "\n  ");
    }

    private static String abbreviate(String value, int maxChars) {
        if (value == null) {
            return "";
        }
        if (value.length() <= maxChars) {
            return value;
        }
        return value.substring(0, maxChars) + "...（已截断）";
    }

    record ToolCallEvidence(String toolName, String arguments, String result,
                            long elapsedMillis, boolean timedOut) {
        ToolCallEvidence {
            toolName = toolName == null ? "" : toolName;
            arguments = arguments == null ? "" : arguments;
            result = result == null ? "" : result;
        }

        boolean successful() {
            if (timedOut || result.isBlank()) {
                return false;
            }
            String normalized = result.trim().toLowerCase(Locale.ROOT);
            return !normalized.startsWith("工具执行失败")
                    && !normalized.startsWith("未知工具")
                    && !normalized.startsWith("读取文件失败")
                    && !normalized.startsWith("写入文件失败")
                    && !normalized.startsWith("执行命令失败")
                    && !normalized.startsWith("命令执行超时")
                    && !normalized.startsWith("用户取消")
                    && !normalized.startsWith("🛡️")
                    && !normalized.startsWith("[hitl]");
        }

        boolean commandSucceeded() {
            return successful() && result.contains("命令执行完成 (exit code: 0)");
        }
    }
}
