package com.paicli.agent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Consumer;
import java.util.function.IntFunction;

/**
 * 单个 {@link AgentOrchestrator} 拥有的 Worker 实例池。
 *
 * <p>Worker 只会处于空闲队列或一个有效 Lease 中。调用方通过 try-with-resources
 * 关闭 Lease 时，池会先清理 Worker 会话，再决定复用或在池已关闭时移除实例。
 */
final class WorkerPool implements AutoCloseable {
    private static final Logger log = LoggerFactory.getLogger(WorkerPool.class);

    private final int maxWorkers;
    private final IntFunction<SubAgent> workerFactory;
    private final ReentrantLock lock = new ReentrantLock();
    private final Condition workerReturned = lock.newCondition();
    private final Deque<SubAgent> availableWorkers = new ArrayDeque<>();
    private final Set<SubAgent> allWorkers = new HashSet<>();
    private boolean closed;
    private int nextWorkerNumber = 1;

    WorkerPool(int minWorkers, int maxWorkers, IntFunction<SubAgent> workerFactory) {
        if (minWorkers < 1) {
            throw new IllegalArgumentException("minWorkers 必须至少为 1");
        }
        if (maxWorkers < minWorkers) {
            throw new IllegalArgumentException("maxWorkers 不能小于 minWorkers");
        }
        if (workerFactory == null) {
            throw new IllegalArgumentException("workerFactory 不能为空");
        }
        this.maxWorkers = maxWorkers;
        this.workerFactory = workerFactory;
        for (int i = 0; i < minWorkers; i++) {
            availableWorkers.addLast(createWorker());
        }
    }

    Lease acquire() throws InterruptedException {
        lock.lockInterruptibly();
        try {
            while (true) {
                ensureOpen();
                SubAgent available = availableWorkers.pollFirst();
                if (available != null) {
                    return new Lease(available);
                }
                if (allWorkers.size() < maxWorkers) {
                    return new Lease(createWorker());
                }
                workerReturned.await();
            }
        } finally {
            lock.unlock();
        }
    }

    int maxWorkers() {
        return maxWorkers;
    }

    Stats stats() {
        lock.lock();
        try {
            int total = allWorkers.size();
            int idle = availableWorkers.size();
            return new Stats(total, idle, total - idle, maxWorkers, closed);
        } finally {
            lock.unlock();
        }
    }

    void forEachWorker(Consumer<SubAgent> action) {
        if (action == null) {
            return;
        }
        List<SubAgent> snapshot;
        lock.lock();
        try {
            snapshot = new ArrayList<>(allWorkers);
        } finally {
            lock.unlock();
        }
        snapshot.forEach(action);
    }

    @Override
    public void close() {
        List<SubAgent> idleWorkers;
        lock.lock();
        try {
            if (closed) {
                return;
            }
            closed = true;
            idleWorkers = new ArrayList<>(availableWorkers);
            availableWorkers.clear();
            allWorkers.removeAll(idleWorkers);
            workerReturned.signalAll();
        } finally {
            lock.unlock();
        }
        idleWorkers.forEach(this::clearHistorySafely);
    }

    private SubAgent createWorker() {
        SubAgent worker = workerFactory.apply(nextWorkerNumber++);
        if (worker == null) {
            throw new IllegalStateException("workerFactory 返回了 null");
        }
        allWorkers.add(worker);
        return worker;
    }

    private void ensureOpen() {
        if (closed) {
            throw new IllegalStateException("WorkerPool 已关闭");
        }
    }

    private void release(SubAgent worker) {
        boolean reusable = clearHistorySafely(worker);
        lock.lock();
        try {
            if (!allWorkers.contains(worker)) {
                return;
            }
            if (closed || !reusable) {
                allWorkers.remove(worker);
            } else {
                availableWorkers.addLast(worker);
            }
            workerReturned.signalAll();
        } finally {
            lock.unlock();
        }
    }

    private boolean clearHistorySafely(SubAgent worker) {
        try {
            worker.clearHistory();
            return true;
        } catch (RuntimeException e) {
            log.warn("Failed to clear history for worker {}, removing it from the pool", worker.getName(), e);
            return false;
        }
    }

    record Stats(int total, int idle, int busy, int max, boolean closed) {
    }

    final class Lease implements AutoCloseable {
        private final SubAgent worker;
        private final AtomicBoolean released = new AtomicBoolean();

        private Lease(SubAgent worker) {
            this.worker = worker;
        }

        SubAgent worker() {
            if (released.get()) {
                throw new IllegalStateException("Worker Lease 已归还");
            }
            return worker;
        }

        @Override
        public void close() {
            if (released.compareAndSet(false, true)) {
                release(worker);
            }
        }
    }
}
